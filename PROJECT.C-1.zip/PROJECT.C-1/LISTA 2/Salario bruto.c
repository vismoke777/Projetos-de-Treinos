#include <stdio.h>
int main() {
    char nome[100];
    char estado[100];
    char sexo [100];
    char cidade[100];
    char endereço[100];
    int idade;
    float salario_bruto, salario_liquido;
    float valetransporte, valealimentação, planodesaúde;
    printf("*****Calcule o salario liquido*****");
    printf("nome....");
    scanf(" %[^\n]", nome);
    printf("estado....");
    scanf(" %[^\n]", estado);
    printf("sexo....");
    scanf(" %c", sexo);
    printf("cidade....");
    scanf(" %[^\n]", cidade);
    printf("endereço....");
    scanf(" %[^\n]", endereço);
    printf("idade....");
    scanf(" %d", &idade);
    printf("salario bruto....");
    scanf(" %f", &salario_bruto);

    valetransporte = salario_bruto * 0.02;
    valealimentação = salario_bruto * 0.05;
    planodesaúde = salario_bruto * 0.10;
    salario_liquido = salario_bruto - valetransporte - valealimentação - planodesaúde;

    printf("nome......: %s\n", nome);
    printf("salario liquido: %.2f\n", salario_liquido);
    printf("salario bruto: %.2f\n", salario_bruto);
    printf("vale transporte: %.2f\n", valetransporte);
    printf("vale alimentação: %.2f\n", valealimentação);
    printf("plano de saúde: %.2f\n", planodesaúde);

    return 0;
}