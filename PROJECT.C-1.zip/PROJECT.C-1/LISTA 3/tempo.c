#include <stdio.h>
int main() {
    int segundos, minutos, horas;
    printf("digite o tempo em segundos:");
    scanf("%d", &segundos);
    horas = segundos / 3600;
    minutos = (segundos % 3600) / 60;
    segundos = segundos % 60;
    
    printf("horas: %d\n", horas);
    printf("minutos: %d\n", minutos);
    printf("segundos: %d\n", segundos); 
    return 0;
}