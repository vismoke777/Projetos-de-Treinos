#include <stdio.h>
#include <math.h>

int main() {
    float litro, area, latasdetinta, valor;

    printf("Digite a area em metros quadrados: ");
    scanf("%f", &area);

    litro = area / 6;
    latasdetinta = ceil(litro / 18);

    valor = latasdetinta * 80;

    printf("A quantidade de latas de tinta necessarias e: %.0f\n", latasdetinta);
    printf("O valor total a ser pago e: R$ %.2f\n", valor);
    printf("A quantidade de litros necessarios e: %.2f\n", litro);

    return 0;
}